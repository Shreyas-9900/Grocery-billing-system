#include <stdio.h>
#include <stdlib.h>
#include "billing_functions.h" // Include the header file for function declarations
#include "billing_functions.c"
int main() {
    // Escape code for green text
    printf("\033[32m");

    // Declare a pointer to a customer structure
    struct Customer *customer_ptr;

    // Allocate memory for a single customer
    customer_ptr = malloc(sizeof(struct Customer));

    // Check if memory allocation was successful
    if (customer_ptr == NULL) {
        printf("Memory allocation failed. Exiting...\n");
        return 1; // Exit with error code
    }

    // Get user data
    get_userdata(customer_ptr);

    // Free the allocated memory
    free(customer_ptr);

    return 0;
}
