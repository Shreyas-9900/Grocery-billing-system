#include <stdio.h>
#include <stdlib.h>
#include "billing_functions.h"

// Global variables for items
char items[][10] = {"Apple(kg)", "Eggs(dz)", "Milk(L)", "Panner(g)", "Bread(pk)", "Coke(1L)", "Tea(pk)", "Curd(ml)", "Lays(pk)", "Cookie(pk)"};
int price[10] = {100, 60, 30, 100, 50, 40, 10, 30, 10, 20};
int stock[10] = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100};
int teststock[10] = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100};

void get_userdata(struct Customer *customer_ptr) {
    printf("\nEnter your name: ");
    scanf("%[^\n]%*c", customer_ptr->name);
    printf("\nEnter customer ID: ");
    scanf("%d", &customer_ptr->cust_id);
    printf("\nEnter phone number: ");
    scanf("%lld", &customer_ptr->ph);
    printf("-------------------------\n");
    display_data(customer_ptr);
}

void display_data(struct Customer *customer_ptr) {
    int i = 2;
    printf("\nYour name: %s", customer_ptr->name);
    printf("\nYour customer ID: %d", customer_ptr->cust_id);
    printf("\nYour phone number: %lld\n", customer_ptr->ph);
    printf("\nConfirm with 1 if the data is correct else press 0\n");
    scanf("%d", &i);

    if (i == 1) {
        display_items();
    } else if (i == 0) {
        printf("-------Re-enter your data------\n");
        get_userdata(customer_ptr);
    }
}

// Define other functions similarly...

void display_items() {
    system("cls");
    printf("\033[0m"); //reset color------------------------------------------------------------------
    printf("\n************\n");
    printf("|ITEMS|   \t|STOCK| |PRICE|\n");
    for(int i = 0; i < 10; i++) {
        printf("%d %s  \t:%d  \t %d\n",(i+1),items[i],stock[i],price[i]);
    }
    printf("Press 0 to exit\n");
    printf("************\n");
    get_input();
}

void get_input() {
    printf("\x1b[33m"); //yellow font--------------------------------------------------
    int qty = 0;
    int choice = 0;
    int i = 1;
    double sum = 0;
    double indsum = 0;
    while(i == 1) {
        printf("\n-------------------------------\n");
        printf("---------Enter-choice----------\n");
        printf("-------------------------------\n");
        scanf("\n%d",&choice);
        switch(choice) {
            case 1:
                printf("Enter the quantity required for Apple: ");
                scanf("%d",&qty);
                if(qty > stock[0]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[0]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[0])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[0] = stock[0] - qty;
                break;
            case 2:
                // Similar cases for other items...
            case 0:
                printf("Exiting...\n");
                gen_bill(sum);
                i = 2;
                break;
            default:
                printf("\033[31m"); //red font
                printf("\nPlease Enter correct choice!\n");
                printf("\x1b[33m"); //yellow font
                break;
        }
    }
}

void gen_bill(double sum) {
    double dis = 0;
    system("cls");
    printf("\033[0m"); //reset color-------------------------------------
    int j = 1;
    printf("-----------------------------BILL-----------------------------\n");
    for(int i = 0; i < 10; i++) {
        if(stock[i] < teststock[i]) { //then the item has been taken
            printf("SN: %d\tITEM: %s\tQTY: %d\tPRICE: %d\tNET PRICE: %d\t\n",j++,items[i],(100-stock[i]),price[i],((100-stock[i])*price[i]));   //s.no|name|qty|price|total
        }
    }

    printf("--------------------------------------------------------------");

    printf("\nTotal cart amount: %lf\n",sum);
    if(sum >= 500) {
        dis = sum * 0.10;
        double tax = (sum - dis) * 0.18;
        printf("\nDiscount: %lf",dis);
        printf("\nTax %lf",tax);
        printf("\nTotal Amt: %lf\n\n\n\n",(sum - dis + tax));
    } else if(sum < 500) {
        double tax = sum * 0.18;
        printf("\nTax: %lf",tax);
        printf("\nTotal Amt: %lf\n\n\n\n",(sum + tax));
    }
}