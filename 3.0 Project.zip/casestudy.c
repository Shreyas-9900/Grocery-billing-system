#include <stdio.h>
#include <stdlib.h>
#include "billing_functions.h"



char items[][10] = {"Apple(kg)", "Eggs(dz)", "Milk(L)", "Panner(g)", "Bread(pk)", "Coke(1L)", "Tea(pk)", "Curd(ml)", "Lays(pk)", "Cookie(pk)"};
int price[10] = {100, 60, 30, 100, 50, 40, 10, 30, 10, 20};
int stock[10] = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100};
int teststock[10] = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100};

void write_customer_data(struct Customer *customer_ptr) {
    FILE *fp;
    fp = fopen("customer_data.txt", "a");

    if (fp == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    fprintf(fp, "%s %d %lld\n", customer_ptr->name, customer_ptr->cust_id, customer_ptr->ph);

    fclose(fp);
}


void read_customer_data() {
    FILE *fp;
    char name[100];
    int cust_id;
    long long int ph;

    fp = fopen("customer_data.txt", "r"); 

    if (fp == NULL) {
        printf("Error opening file for reading.\n");
        return;
    }

    printf("\nCustomer Data:\n");
    while (fscanf(fp, "%s %d %lld", name, &cust_id, &ph) != EOF) {
        printf("Name: %s, ID: %d, Phone: %lld\n", name, cust_id, ph);
    }

    fclose(fp);
}


void search_customer_by_id(int cust_id) {
    FILE *fp;
    char name[100];
    long long int ph;
    int found = 0;

    fp = fopen("customer_data.txt", "r"); 

    if (fp == NULL) {
        printf("Error opening file for reading.\n");
        return;
    }

    while (fscanf(fp, "%s %d %lld", name, &cust_id, &ph) != EOF) {
        if (cust_id == cust_id) {
            printf("Customer found:\n");
            printf("Name: %s\tID: %d\tPhone: %lld\n", name, cust_id, ph);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Customer not found.\n");
    }

    fclose(fp);
}

void get_userdata(struct Customer *customer_ptr) {
    printf("\nEnter your name: ");
    scanf("%[^\n]%*c", customer_ptr->name);
    printf("\nEnter customer ID: ");
    scanf("%d", &customer_ptr->cust_id);
    printf("\nEnter phone number: ");
    scanf("%lld", &customer_ptr->ph);
    printf("-------------------------\n");
    write_customer_data(customer_ptr); 
    display_data(customer_ptr);
}

void display_data(struct Customer *customer_ptr) {
    int i = 2;
    printf("\nYour name: %s", customer_ptr->name);
    printf("\nYour customer ID: %d", customer_ptr->cust_id);
    printf("\nYour phone number: %lld\n", customer_ptr->ph);
    printf("\nConfirm with 1 if the data is correct else press 0\n");
    scanf("%d", &i);

    if (i == 1) {
        display_items();
    } else if (i == 0) {
        printf("-------Re-enter your data------\n");
        get_userdata(customer_ptr);
    }
}



void display_items() {
    system("cls");
    printf("\033[0m"); 
    printf("\n************\n");
    printf("|ITEMS|   \t|STOCK| |PRICE|\n");
    for(int i = 0; i < 10; i++) {
        printf("%d %s  \t:%d  \t %d\n",(i+1),items[i],stock[i],price[i]);
    }
    printf("Press 0 to exit\n");
    printf("************\n");
    get_input();
}

void get_input() {
    printf("\x1b[33m");
    int qty = 0;
    int choice = 0;
    int i = 1;
    double sum = 0;
    double indsum = 0;
    while(i == 1) {
        printf("\n-------------------------------\n");
        printf("---------Enter-choice----------\n");
        printf("-------------------------------\n");
        scanf("\n%d",&choice);
        switch(choice) {
            case 1:
                printf("Enter the quantity required for Apple: ");
                scanf("%d",&qty);
                if(qty > stock[0]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[0]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[0])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[0] = stock[0] - qty;
                break;
            case 2:
                printf("Enter the quantity required for eggs: ");
                scanf("%d",&qty);
                if(qty > stock[1]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[1]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[1])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[1] = stock[1] - qty;
                break;
            case 3:
                printf("Enter the quantity required for milk: ");
                scanf("%d",&qty);
                if(qty > stock[2]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[2]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[2])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[2] = stock[2] - qty;
                break;
            case 4:
                printf("Enter the quantity required for panner: ");
                scanf("%d",&qty);
                if(qty > stock[3]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[3]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[3])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[3] = stock[3] - qty;
                break;
            case 5:
                printf("Enter the quantity required for bread: ");
                scanf("%d",&qty);
                if(qty > stock[4]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[0]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[4])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[4] = stock[4] - qty;
                break;
            case 6:
                printf("Enter the quantity required for coke: ");
                scanf("%d",&qty);
                if(qty > stock[5]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[0]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[5])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[5] = stock[5] - qty;
                break;
            case 7:
                printf("Enter the quantity required for tea: ");
                scanf("%d",&qty);
                if(qty > stock[6]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[0]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[6])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[6] = stock[6] - qty;
                break;
            case 8:
                printf("Enter the quantity required for curd: ");
                scanf("%d",&qty);
                if(qty > stock[7]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[0]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[7])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[7] = stock[7] - qty;
                break;
            case 9:
                printf("Enter the quantity required for lays: ");
                scanf("%d",&qty);
                if(qty > stock[8]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[0]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[8])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[8] = stock[8] - qty;
                break;
            case 10:
                printf("Enter the quantity required for cookie: ");
                scanf("%d",&qty);
                if(qty > stock[9]) {
                    printf("OUT OF STOCK");
                    break;
                }

                indsum = price[9]*qty;
                printf("Price of item for %d Quantities: %lf\n",qty,indsum);
                sum = sum + (price[9])*qty;
                printf("Total cart Sum: %lf\n",sum);
                stock[9] = stock[9] - qty;
                break;

            case 0:
                printf("Exiting...\n");
                gen_bill(sum);
                i = 2;
                break;
            default:
                printf("\033[31m");
                printf("\nPlease Enter correct choice!\n");
                printf("\x1b[33m");
                break;
        }
    }
}

void gen_bill(double sum) {
    double dis = 0;
    system("cls");
    printf("\033[0m"); 
    int j = 1;
    printf("-----------------------------BILL-----------------------------\n");
    for(int i = 0; i < 10; i++) {
        if(stock[i] < teststock[i]) { 
            printf("SN: %d\tITEM: %s\tQTY: %d\tPRICE: %d\tNET PRICE: %d\t\n",j++,items[i],(100-stock[i]),price[i],((100-stock[i])*price[i]));   //s.no|name|qty|price|total
        }
    }

    printf("--------------------------------------------------------------");

    printf("\nTotal cart amount: %lf\n",sum);
    if(sum >= 500) {
        dis = sum * 0.10;
        double tax = (sum - dis) * 0.18;
        printf("\nDiscount: %lf",dis);
        printf("\nTax %lf",tax);
        printf("\nTotal Amt: %lf\n\n\n\n",(sum - dis + tax));
    } else if(sum < 500) {
        double tax = sum * 0.18;
        printf("\nTax: %lf",tax);
        printf("\nTotal Amt: %lf\n\n\n\n",(sum + tax));
    }
}

int main() {
    printf("\033[32m");

    struct Customer *customer_ptr;

    customer_ptr = malloc(sizeof(struct Customer));

    if (customer_ptr == NULL) {
        printf("Memory allocation failed. Exiting...\n");
        return 1; 
    }

    
    get_userdata(customer_ptr);

    write_customer_data(customer_ptr);

    
    free(customer_ptr);

    
    int search_id;
    printf("Enter the customer ID to search: ");
    scanf("%d", &search_id);

    search_customer_by_id(search_id);


    return 0;
}
